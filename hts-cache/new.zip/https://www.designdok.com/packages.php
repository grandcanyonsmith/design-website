
<html lang="en-US"
  itemscope 
  itemtype="http://schema.org/WebSite" 
  prefix="og: http://ogp.me/ns#" >
<head>
    
<title>Get the perfect logo design - or any design in over 90 categories!</title>
<meta name="description"  content="Design Dok is a digital design agency specializing in branding, animation, mobile and web design and development." />

     

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">




<link href="favicon.ico" rel="icon" />

      
<link rel='dns-prefetch' href='//s.w.org' />

<!--<link rel='stylesheet' id='main-style-css'  href='assets/css/mstyle.css' type='text/css' media='all' />-->
<link rel='stylesheet' id='main-style-css'  href='assets/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-style-css'  href='assets/css/m-style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-style-css'  href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css' type="text/css" />

<!--[if IE]>
  <script src="assets/js/html5.js"></script>
<![endif]-->

 

</head>

<body class="home blog pakgespage">

    <div class="app-content">
      <div class="main">

        

<noscript>
<div id="jqcheck"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB60lEQVQ4T2NkwAHePzrxf3ebL1jWp/0oA5egGiM2pVgFQQq31uj/N/ANZvj+8T3D7aNHGDwbTxNvwKtbO/9f3dLHYJ+axfDn5w+GI/NnMRhFtTEISJtjGIIh8Pv39/87ak0ZzCLiGMRUNMCufnLxDMOlrZsY3JtOMrCwsKPowTDg3tGZ/59f2sVgFRvPkO+bAzZgwsZJDEcXzWNQtIlikDGIwG3Az+9v/+9qsGOwTc1h4JeQhhswcfMUhrcP7zEcXzyXwb3xMAMbuwDcEBTTzi7P/s/M8IFB3zccbDPMBSADQODs2sUMzFwyDIah/ZgGfHt/7/+BvmAGm+RsBl4RMawGfHr5jOHowlkMjiUbGDj55MCGwE060Of1X0RZi0Hb2Q4e3eguAElc2X2A4e2DmwwOhVsRBnx6cfH/yXm5DFZxyQxcAoJ4Dfj24T3DsUVzGcwSJjLwSxkygk3ZVmv4X805gkHZRBNXwkQRv3/+NsP1nUsYvFvOMzI+PLXo/73DSxgsouIYOHj5UBRi8wJIwY8vnxlOLV/CIGcewsC4vkDhv01yLoOIoiqG7bgMACn88Owxw8HpvQyMGwqV/vs19TMwQnxDEthYW8DAeGCC3/9XN46TpBGmWEzDkoHx06dP/z9//kyWAby8vAwAcza2SBMOSCMAAAAASUVORK5CYII=" alt="No Script" /> Javascript is disabled. Please enable it for better working experience.</div>
</noscript>
<header class="header-home fill"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<a href="https://www.designdok.com/">
    <div class="logo">
       <img src="assets/images/logo.svg" alt=""> 
      <!--<img src="assets/images/design-dok-christmas.png" alt=""> -->
    </div>
</a>

  <div class="menu-wrap">
      <a class="mobile-hireus num" href="tel:+18627721016">+1 862 772 1016</a>

    <a class="mobile-hireus gotoform" href="Javascript:;">Hire us</a>

    <button class="hamburger hamburger--spring js-hamburger" type="button"
  aria-label="Menu" aria-controls="navigation" aria-expanded="true/false">
      <span class="hamburger-box">
      <span class="hamburger-inner"></span>
      </span>
    </button>

    <div class="menu">
      <ul id="menu" class="">
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4971 homeclass hidemenu"><a href="https://www.designdok.com/">Home</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4970 dropdown hidemenu">
          <a href="https://www.designdok.com/services">Services</a>
          <ul class="ddlist">
            <li><a href="https://www.designdok.com/logo-design" class="active">Logo Design</a></li>
            <li><a href="https://www.designdok.com/branding">Branding</a></li>
            <li><a href="https://www.designdok.com/website-design-development">Website Design & Development</a></li>
            <li><a href="https://www.designdok.com/motion-graphics">Motion Graphics</a></li>
            <li><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li><a href="https://www.designdok.com/seo">SEO</a></li>
            <li><a href="https://www.designdok.com/content">Book Writing</a></li>
          </ul>
        </li>
        
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="https://www.designdok.com/works">Portfolio</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="packages">Packages</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="combo-packages">Combo Packages</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5247 hidemenu"><a href="https://www.designdok.com/reviews">Reviews</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5247 hidemenu"><a href="https://www.designdok.com/how-it-works">How It Works</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="https://www.designdok.com/company">Company</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973"><a class="headnumber" href="tel:+18627721016"><i class="fa fa-phone"></i>+1 862 772 1016</a></li>
        <li class="hire-us menu-item menu-item-type-post_type menu-item-object-page menu-item-4974 hidemenu"><a href="https://www.designdok.com/contact">Get a Quote</a></li>
        <li class="hire-us menu-item menu-item-type-post_type menu-item-object-page menu-item-4974 gotoform"><a href="Javascript:;">Hire us</a></li>
        
      </ul>
      <div class="close-i"></div>
    </div>    
  </div>


<div class="topformcontainer">
    <div class="topformwrap">
      <div class="formheading">
        <h2>Let's Get Started Exclusive Offer </h2>
      </div>
      <div class="formbody">
        <div class="container">
  <div class=" col-lg-12 col-xl-12 text-center">
    <div class="home-banner-content"  >
      <div class="analyzeform col-lg-10 offset-lg-1">
        <form class="" id="banform" method="POST" action="webpages/bannerFormController.php">
          <div class="row">
            <div class="wrap">
              <div class="dtf">
                <input id="fname" name="bName" autocomplete="off" minlength="5" class="round" type="text" placeholder="Enter Name" required="">
              </div>
              <div class="dtf">
                <input id="cemail" type="email" autocomplete="off" name="bEmail" placeholder="Enter email here" required="">
              </div>
              <div class="dtf">
                <input id="phone-coun" name="bNumber" autocomplete="off" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
              </div>
              <div class="dtf">
                <textarea name="bMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
              </div>
              <div class="dtf text-left">
                <input class="submit" type="submit" value="Contact Team">
                <script type="565a0cabfa86dd5c263cfb77-text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
                    <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
              <input type="hidden" id="location" name="blocationURL" value="" />
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>      </div>
    </div>
    <div class="topformswitch">
      <div class="switchicon">
        <span class="fa fa-chevron-down"></span>
      </div>
      <h4>Avail <span>50%</span> DISCOUNT</h4>
    </div>
  </div>
  
    <!--<div class="eggoffer">-->
    <!--    <a href="javascript:;" onclick="setButtonURL()">-->
    <!--      <div class="top">-->
    <!--        <figure>-->
              <!--<img src="assets/images/blackfriiday.png">-->
    <!--        <img src="assets/images/christmas.png">-->
    <!--        </figure>-->
    <!--      </div>-->
    <!--    </a>-->
    <!--</div> -->

</header>






<div class="works-wrap">

<section class="mypackages">
    <div class="container">
        <div class="row">
            <div class="left information">
                <h2 class="title myheading">My Packages</h2>
                    
                <p class="mytext">DesignDok can help visualize even the craziest ideas converting them into elegant designs, awesome experiences and catchy brands.</p>
            </div>
            <div class="tab-custom">
                <ul class="tabbing-links">
                      <li class="current" data-targetit="tabs-wdpackages">Web Design</li>
                       <li data-targetit="tabs-ecpackages">eCommerce Packages</li>
                       <li data-targetit="tabs-webmain">Web Maintenance</li>
                        <li data-targetit="tabs-vdpackages">Video Animation</li>
                         <li data-targetit="tabs-3dpackages">3D Animation</li>
                         <li data-targetit="tabs-brandingpackages">Branding</li>
                  <li  data-targetit="tabs-ldpackages">Logo Design</li>
                
                 
                 <!-- 
                  <li data-targetit="tabs-seopackages">SEO Packages</li> -->
                 
                  
                  <li data-targetit="tabs-bookwritingpackages">Book Writing</li>
                </ul>
            
            
                <div class="tabs tabs-ldpackages  row">
                <div class="container">
  <div class="row packslider">
  
  <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Revamp logo <br>Package </h3>
                  <p class=""><span class="strike">$69.98</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$34.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=1'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li><strong>2</strong> Custom Logo Design Concepts by 2 Designers</li>
                  <li><strong>2</strong> Revisions</li>
                  <li><strong>48</strong> to 72 hours TAT</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Unique Design Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee*</li>
              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Startup logo <br>Package</h3>
                  <p class=""><span class="strike">$129.99</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$64.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=2'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
               <ul class="details">
                   <li><strong>4</strong> Custom Logo Design Concepts</li>
                    <li>By <strong>2</strong> Designers</li>
                    <li>Unlimited Revisions</li>
                    <li><strong>48</strong> to 72 hours TAT</li>
                    <li><strong>100%</strong> Satisfaction Guarantee</li>
                    <li><strong>100%</strong> Unique Design Guarantee</li>
                    <li><strong>100%</strong> Money Back Guarantee*</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">Best Seller</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Professional Logo <br>Package</h3>
                  <p class=""><span class="strike">$229.98</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$114.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=3'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                   <li>Unlimited Logo Design Concepts</li>
                  <li>By <strong>4</strong> Industry Based Designers</li>
                  <li><strong>UNLIMITED</strong> Revisions</li>
                  <li><strong>FREE</strong> MS Electronic Letterhead</li>
                  <li><strong>FREE</strong> Custom Stationery Design (Letterhead, Business Card,  Envelope)</li>
                  <li><strong>48</strong> to <strong>72</strong> hours TAT</li>
                  <li><strong>FREE</strong> File Formats (EPS, Ai, GIF, JPEG, PSD)</li>
                  <li><strong>100%</strong> Satisfaction Guarantee</li>
                  <li><strong>100%</strong> Unique Design Guarantee</li>
                  <li><strong>100%</strong> Money Back Guarantee</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Identity Logo <br>Package</h3>
                  <p class=""><span class="strike">$329.98</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$164.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=4'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                    <li>Unlimited Logo Design Concepts by 8 Designers</li>
                    <li>FREE Icon Design</li>
                    <li>FREE Unlimited Revisions</li>
                    <li>Turnaround time 2-3 business days</li>
                    <li>1 Stationery Design Set (Business card, Letterhead, Envelope &amp; Email Signature)</li>
                    
                    <li>100% Satisfaction Guarantee</li>
                    <li>100% Money Back Guarantee*</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Corporate Logo <br>Package</h3>
                  <p class=""><span class="strike">$429.98</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$214.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=5'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                      <li><strong>UNLIMITED</strong> Logo Design Concepts</li>
                      <li>By <strong>6</strong> Award Winning Designers</li>
                      <li><strong>Free</strong> Icon Design</li>
                      <li><strong>FREE</strong> Custom Stationery Design (Letterhead, Business Card, Envelope, Invoice)</li>
                      <li>Double Side Flyer (OR) Bi-Fold Brochure</li>
                      <li><strong>FREE</strong> MS Electronic Letterhead</li>
                      <li>Email Signature Design</li>
                      <li>UNLIMITED Revisions</li>
                      <li>48 to 72 hours TAT</li>
                      <li><strong>100%</strong> Satisfaction Guarantee</li>
                      <li><strong>100%</strong> Unique Design Guarantee</li>
                      <li><strong>100%</strong> Money Back Guarantee</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Elite Logo <br>Package</h3>
                  <p class=""><span class="strike">$829.98</span></p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$414.99 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=6'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                      <li><strong>UNLIMITED</strong> Logo Design Concepts</li>
                      <li>By <strong>8</strong> Design Artist</li>
                      <li><strong>UNLIMITED</strong> Revisions</li>
                      <li><strong>2</strong> Stationary Design Sets</li>
                      <li><strong>FREE</strong> MS Word Letterhead</li>
                      <li><strong>Free</strong> Email Signature</li>
                      <li><strong>3</strong> Page Custom Website</li>
                      <li>Mobile Responsive</li>
                      <li><strong>2</strong> Stock Photos</li>
                      <li><strong>2</strong> Banner Designs</li>
                      <li>jQuery Slider</li>
                      <li>All Final Files Format (AI, PSD, EPS, PNG, GIF, JPG, PDF)</li>
                      <li><strong>100%</strong> Ownership Rights</li>
                      <li><strong>100%</strong> Satisfaction Guarantee</li>
                      <li><strong>100%</strong> Unique Design Guarantee</li>
                      <li><strong>100%</strong> Money Back Guarantee *</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
                <p>20% more OFF on Next Order</p>
              
              
            </div>
          </div>
        </div>
      </div>  
</div>
</div>                </div>
                <div class="tabs tabs-webmain  row">
                <div class="container">
  <div class="row packslider justify-content-center">
    
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Basic Web Maintenance  <br>Package </h3>
            <p class=""><span class="strike">$150.00</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$99.00 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=44'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Free Domain <span class="circle"></span></li>
                <li>Website Hosting</li>
                <li>SSL Certificate  Integration</li>
                <li>Disk Space  10GB <span class="circle"></span></li>
                <li>Email Accounts 10</li>
                <li>Monthly Bandwidth Unlimited</li>
                <li>CPUs 1</li>
                <li>Memory  1024</li>
                <li>Database backup/restore</li>
                <li>Strategic assistance</li>
                <li>Plugins Integration</li>
                <li>Technical optimization</li>
                <li>Site Structure Optimisation</li>
                <li>100% Satisfaction Guaranteed</li>
                <!--  <li><strong>2</strong> Custom Logo Design Concepts by 2 Designers</li>
                <li><strong>2</strong> Revisions</li>
                <li><strong>48</strong> to 72 hours TAT</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee*</li> -->
              </ul>
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3>Enterprise Web Maintenance <br>Package</h3>
            <p class=""><span class="strike">$299.99</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$199.00 </h2>
            </div>
            <div class="packinner">
              <!-- <p>The most important functional ties for your teams-perfectly integrated from one vendor.</p> -->
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=45'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>2 Free Domain <span class="circle"></span></li>
                <li>Website Hosting</li>
                <li>Strategic assistance <span class="circle"></span></li>
                <li>On-page SEO</li>
                <li>Google Analytics Integration <span class="circle"></span></li>
                <li>Webmaster Integration</li>
                <li>Plugins Integration</li>
                <li>Technical optimization</li>
                <li>Site Structure optimisation</li>
                <li>SSL Certificate  Integration</li>
                <li>Disk Space  35GB</li>
                <li>Email Accounts 0</li>
                <li>Monthly Bandwidth Unlimited</li>
                <li>CPUs 2</li>
                <li>Memory  2048</li>
                <li>Database backup/restore</li>
                <li>FTP Users 2</li>
                <li>100% Satisfaction Guaranteed</li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>20% more OFF on Next Order</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4"></div>
  </div>
</div>                </div>

                <div class="tabs tabs-wdpackages current row">
                <div class="container">
  <div class="row packslider">
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Basic Web <br>Package</h3>
            <p class=""><span class="strike">$398.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$199.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=7'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li><strong>2</strong> Stock Images</li>
                <li><strong>3</strong> Page Website</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li>Contact/Query Form</li>
                <li>48 to 72 hours TAT</li>
                <li>Complete Deployment</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">Popular</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Startup Web <br>Package</h3>
            <p class=""><span class="strike">$596.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$399.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=8'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li><strong>5</strong> Stock Photos</li>
                <li><strong>5</strong> Page Website</li>
                <li><strong>3</strong> Banner Design</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li><strong>FREE</strong> Google Friendly Sitemap</li>
                <li>48 to 72 hours TAT</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
                <li>Mobile Responsive will be Additional $200*</li>
                <li>CMS will be Additional <strong>$250*</strong></li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Professional Website <br> Package</h3>
            <p class=""><span class="strike">$1,398.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$699.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=9'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li><strong>10</strong> Unique Pages Website</li>
                <li>CMS / Admin Panel Support</li>
                <li><strong>8</strong> Stock images</li>
                <li><strong>5</strong> Banner Designs</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li><strong>FREE</strong> Google Friendly Sitemap</li>
                <li>48 to 72 hours TAT</li>
                <li>Complete Deployment</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
                <li>Mobile Responsive will be Additional <strong>$200*</strong></li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Elite  Website <br> Package</h3>
            <p class=""> <span class="strike">$2,598.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1,299.00</h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=10'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Upto <strong>15</strong> Unique Pages Website</li>
                <li>Conceptual and Dynamic Website</li>
                <li>Mobile Responsive</li>
                <li>Online Reservation/Appointment Tool (Optional)</li>
                <li>Online Payment Integration (Optional)</li>
                <li>Custom Forms</li>
                <li>Lead Capturing Forms (Optional)</li>
                <li>Striking Hover Effects</li>
                <li>Newsletter Subscription (Optional)</li>
                <li>Newsfeed Integration</li>
                <li>Social Media Integration</li>
                <li>Search Engine Submission</li>
                <li><strong>5</strong> Stock Photos</li>
                <li><strong>3</strong> Unique Banner Design</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li>48 to 72 hours TAT</li>
                <li>Complete Deployment</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Corporate  Website <br> Package</h3>
            <p class=""><span class="strike">$3,998.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1,999.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=11'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li><strong>15</strong> to <strong>20</strong> Pages Website</li>
                <li>Custom Made, Interactive, Dynamic &amp; High End Design</li>
                <li>Custom WP (or) Custom PHP Development</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li>Up to <strong>10</strong> Custom Made Banner Designs</li>
                <li><strong>10</strong> Stock Images</li>
                <li>Unlimited Revisions</li>
                <li>Special Hoover Effects</li>
                <li>Content Management System (CMS)</li>
                <li>Online Appointment/Scheduling/Online Ordering Integration (Optional)</li>
                <li>Online Payment Integration (Optional)</li>
                <li>Multi Lingual (Optional)</li>
                <li>Custom Dynamic Forms (Optional)</li>
                <li>Signup Area (For Newsletters, Offers etc.)</li>
                <li>Search Bar</li>
                <li>Live Feeds of Social Networks integration (Optional)</li>
                <li>Mobile Responsive</li>
                <li>FREE <strong>5</strong> Years Domain Name</li>
                <li><strong>Free</strong> Google Friendly Sitemap</li>
                <li>Search Engine Submission</li>
                <li>Industry Specified Team of Expert Designers and Developers</li>
                <li>Complete Deployment</li>
                <li>Dedicated Accounts Manager</li>
                <li><strong>100%</strong> Ownership Rights</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>

    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Business  Website <br> Package</h3>
            <p class=""> <span class="strike">$4,998.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$2,499.00</h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=12'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li><strong>15</strong> Seconds 2D Explainer Video</li>
                <li>Voice - Over &amp; Sound Effects</li>
                <li>Professional Script Writing</li>
                <li>Storyboard</li>
                <li>SEO Meta Tags</li>


                <li><strong>15</strong> to <strong>20</strong> Pages Website</li>
                <li>Custom Made, Interactive, Dynamic &amp; High End Design</li>
                <li>Custom WP (or) Custom PHP Development</li>
                <li><strong>1</strong> jQuery Slider Banner</li>
                <li>Up to <strong>10</strong> Custom Made Banner Designs</li>
                <li><strong>10</strong> Stock Images</li>
                <li><strong>Unlimited</strong> Revisions</li>
                <li>Special Hoover Effects</li>
                <li>Content Management System (CMS)</li>
                <li>Online Appointment/Scheduling/Online Ordering Integration (Optional)</li>
                <li>Online Payment Integration (Optional)</li>
                <li>Multi Lingual (Optional)</li>
                <li>Custom Dynamic Forms (Optional)</li>
                <li>Signup Area (For Newsletters, Offers etc.)</li>
                <li>Search Bar</li>
                <li>Live Feeds of Social Networks integration (Optional)</li>
                <li>Mobile Responsive</li>
                <li><strong>FREE</strong> <strong>5</strong> Years Domain Name</li>
                <li><strong>Free</strong> Google Friendly Sitemap</li>
                <li>Search Engine Submission</li>
                <li>Industry Specified Team of Expert Designers and Developers</li>
                <li>Complete Deployment</li>
                <li>Dedicated Accounts Manager</li>
                <li><strong>100%</strong> Ownership Rights</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
              
            </div>
          </div>
          
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>                  </div>

                <div class="tabs tabs-ecpackages row">
                <div class="container">
  <div class="row packslider">
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Startup E-Commerce <br>Package</h3>
            <p class=""><span class="strike">$1,588.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$794.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=13'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Customized Design</li>
                <li>Up-to <strong>100</strong> Products</li>
                <li>Content Management System (CMS)</li>
                <li><strong>Mini</strong> Shopping Cart Integration</li>
                <li>Payment Module Integration</li>
                <li><strong>Easy</strong> Product Search</li>
                <li>Dedicated designer &amp; developer</li>
                <li><strong>Unlimited</strong> Revisions</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
            </div>
            
          </div>
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">Popular</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Professional E-Commerce <br>Package</h3>
            <p class=""><span class="strike">$2,788.00 Only</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1,394.00 </h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=14'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Customized Design</li>
                <li>Up-to <strong>500</strong> Products</li>
                <li>Content Management System (CMS)</li>
                <li>Full Shopping Cart Integration</li>
                <li>Payment Module Integration</li>
                <li>Easy Product Search</li>
                <li>Product Reviews</li>
                <li><strong>5</strong> Promotional Banners</li>
                <li>Team of Expert Designers &amp; Developers</li>
                <li>Unlimited Revisions</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Unique Design Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee *</li>
              </ul>
            </div>
          </div>
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Elite E-Commerce <br>Package</h3>
            <p class=""> <span class="strike">$4999.99</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$2499.99</h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=15'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Unlimited Pages Website with Unique Design</li>
                <li><strong>5</strong> Custom Logo Design</li>
                <li>CMS / Backend Adminstrative System</li>
                <li>Unlimited Products with Unlimited Categories</li>
                <li><strong>FREE</strong> Unlimited Revisions</li>
                <li>Custom Shopping Cart Integration</li>
                <li>Multiple Payment Module Integration</li>
                <li>Multiple Shipping Module Integration</li>
                <li>Product Ratings &amp; Reviews</li>
                <li>Sales &amp; Inventory Management System</li>
                <li>Multiple Currency Support</li>
                <li>Customer Login Area (Sign-Up &amp; Sign-In)</li>
                <li>Mobile Responsive</li>
                <li>Social Media Designs (Facebook, Twitter, Youtube)</li>
                <li>Dedicated Team of Expert Designers &amp; Developers</li>
                <li>Dedicated Project Manager</li>
                <li>News Letter Subscription</li>
                <li><strong>100%</strong> Satisfaction Guarantee</li>
                <li><strong>100%</strong> Money Back Guarantee*</li>
              </ul>
              
            </div>
          </div>
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="packagebox">
        <p class="populartag">&nbsp;</p>
        <div class="">
          <div class="packhdbox">
            <h3 >Business E-Commerce <br>Package</h3>
            <p class=""> <span class="strike">$7,500</span></p>
          </div>
          <div class="pack-wrap">
            <div class="packpricing">
              <h2>$4,999</h2>
            </div>
            <div class="packinner">
              <p>Suitable for potential super-startups and brand revamps for companies.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=46'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                <li>Complete Custom Design & Development</li>
                <li>Unique, User Friendly, Interactive, Dynamic, High End UI Design</li>
                <li>Unlimited Banner Designs</li>
                <li>Interactive Sliding Banners</li>
                <li>Special Hover Effects</li>
                <li>Customized Contact us Form</li>
                <li>Multiple Filtration Option (Search by Age, Experience, Talent, Industry etc)</li>
                <li>Profile Comparison (As per Category) </li>
                <li>File Converter</li>
                <li>Custom Video Functionality</li>
                <li>Multiple File format Uploading</li>
                <li>User Signup Area ( Talent )</li>
                <li>User Signup Area ( Casting )</li>
                <li>User Signup Area ( Agency )</li>
                <li>Client/User Dashboard Area</li>
                <li>Vendor / Agency Dashboard Area</li>
                <li>Custom Coding and Development</li>
                <li>Content Management System (Custom)</li>
                <li>Online Appointment/Scheduling integration (Optional)</li>
                <li>Online Payment Integration</li>
                <li>Invoicing System</li>
                <li>Automated Email Notifications</li>
                <li>Multi Lingual (Optional)</li>
                <li>Custom Dynamic Forms</li>
                <li>Complete Database Creation</li>
                <li>3rd Party Links integration (Instagram, IMDB etc )</li>
                <li>Signup Automated Email Authentication</li>
                <li>Signup Area (For Newsletters, Offers etc.)</li>
                <li>Search Bar for Easy Search</li>
                <li>Live Feeds of Social Networks integration (Optional)</li>
                <li>Search Engine Submission</li>
                <li>SEO friendly</li>
                <li>Mobile Responsive</li>
                <li>Master Admin Panel</li>
                <li>SSL Certification ( to make the website and it’s informative secured ) </li>
                <li>1 Year Free Hosting</li>
                <li>6 Months of Free Maintenance </li>
                <li>Award Winning Team of Expert Designers and Developers</li>
                <li>Complete Deployment</li>
                <li>Complete W3C Validation</li>
                <li>Dedicated Team of Designers and Developers</li>
              </ul>
              
            </div>
          </div>
          <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
          <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
          <div class="addnotes ">
            <p>Add on: $500 for expedited services</p>
            
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>                </div>

                <div class="tabs tabs-vdpackages row">
                <div class="container">
  <div class="row packslider">
<!--    <div class="col-sm-4">-->
<!--  <div class="packagebox">-->
<!--    <p class="populartag">&nbsp;</p>-->
<!--    <div class="">-->
<!--      <div class="packhdbox">-->
<!--        <h3 >Teaser Video <br>Package</h3>-->
<!--        <p class="">Motion</p>-->
<!--      </div>-->
<!--      <div class="pack-wrap">-->
<!--        <div class="packpricing">-->
<!--          <h2>$149.00 <span class="strike">&nbsp;</span></h2>-->
<!--        </div>-->
<!--        <div class="packinner">-->
<!--          <p>Suitable for potential super-startups and brand revamps for companies.</p>-->
<!--        </div>-->
<!--        <button class="packbtn" onClick="location.href='order?pack=16'">Order Now</button>-->
<!--        <div class="list-scroll">-->
<!--          <ul class="details">-->
<!--            <li>15s Duration - HD 1080</li>-->
<!--            <li>Professional Script</li>-->
<!--            <li>Storyboard Design</li>-->
<!--            <li>Animations &amp; VFX</li>-->
<!--            <li>Music And Foley</li>-->
<!--            <li>Voice Over Artists</li>-->
<!--          </ul>-->
<!--        </div>-->
<!--      </div>-->
      
<!--      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>-->
<!--      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>-->
<!--      <div class="addnotes ">-->
<!--        <p>Let's Create</p>-->
        
        
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">Popular</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Startup Video <br>Package</h3>
        <p class="">Motion</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$399.00 <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=17'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li><strong>30s</strong> Duration - HD 1080</li>
            <li>Professional Script</li>
            <li>Storyboard Design</li>
            <li>Animations &amp; VFX</li>
            <li>Music And Foley</li>
            <li>Voice Over Artists</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
       <p>Let's Create</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Classic Video <br>Package</h3>
        <p class="">Motion</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$799.00 <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=18'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li><strong>60</strong> Second Video</li>
            <li>Professional Script</li>
            <li>Storyboard Design</li>
            <li>Animations &amp; VFX</li>
            <li>Music And Foley</li>
            <li>Voice Over Artists</li>
            <li>Unlimited Revisions</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
        <p>Let's Create</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Premium Video <br>Package</h3>
        <p class="">Motion</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$1495.00 <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=19'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li>90 Second Video</li>
            <li>Professional Script</li>
            <li>Storyboard Design</li>
            <li>Animations &amp; VFX</li>
            <li>Music And Foley</li>
            <li>Voice Over Artists</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
        <p>Let's Create</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Deluxe Video <br>Package</h3>
        <p class="">Motion</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$1995.00 <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=20'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li>120 Second Video</li>
            <li>Professional Script</li>
            <li>Storyboard Design</li>
            <li>Animations &amp; VFX</li>
            <li>Music And Foley</li>
            <li>Voice Over Artists</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
        <p>Let's Create</p>
        
        
      </div>
    </div>
  </div>
</div>
  </div>
</div>                </div>

                <div class="tabs tabs-seopackages row">
                <div class="container">
  <div class="row packslider">
 <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Startup Plan </h3>
                  <p class="">Simple Start</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$350 <span class="fm">First Month</span></h2>
            </div>
            <div class="packinner">
              <p>Suitable for newly formed organizations or small incubated startups</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=21'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li class="heading"><strong><i>Campaign Setup And Optimization</i></strong> </li>
                  <li>Website Audit</li>
                  <li>Pages Optimized <strong>(10 pages)</strong> </li>
                  <li><strong>15</strong> Selected Keywords Targeting </li>
                  <li>Keyword Research </li>
                  <li>Keyword Grouping </li>
                  <li>Keyword Mapping </li>
                  <li class="heading"><strong><i>On-Page Optimization</i></strong> </li>
                  <li>SEO Road Map</li>
                  <li>Blog Creation</li>
                  <li>Webpage Copywriting (<strong>3 pages</strong> , <strong>350 words per page</strong> )</li>
                  <li>Title Tag Optimization (<strong>10</strong> titles)</li>
                  <li>Meta Description Optimization (<strong>10 meta description</strong> )</li>
                  <li>Meta Keyword Optimization (<strong>10 meta keywords</strong> )</li>
                  <li>Domain Redirect Optimization (<strong>10 domain redirects</strong> )</li>
                  <li>xml Sitemap Optimization</li>
                  <li>Robots.txt Check</li>
                  <li>URL Rewrites (<strong>10 URL rewrites</strong> )</li>
                  <li>Broken Link Report</li>
                  <li class="heading"><strong><i>Rich Snippet Recommendations </i></strong> </li>
                  <li>Breadcrumbs</li>
                  <li class="heading"><strong><i>Initial Off-Page SEO</i></strong> </li>
                  <li>Social Bookmarking</li>
                  <li>Slide Share Marketing</li>
                  <li>Forums/FAQ’s</li>
                  <li>Link Building</li>
                  <li>Directory Submission</li>
                  <li>Local Business Listings</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes ">
                  <p>$950 – Quarterly Plan</p>
                  <p>$300 – Recurring Monthly Payment</p>
                  
                  
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">Popular</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Scaling Plan </h3>
                  <p class="">Essentials</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$700 <span class="fm">First Month</span></h2>
            </div>
            <div class="packinner">
              <p>For medium-sized stable organizations looking to climb up the corporate ladder.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=22'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
               <ul class="details">
                  <li class="heading"><strong><i></i></strong> </li>
                  <li>Business Analysis</li>
                  <li>Consumer Analysis </li>
                  <li>Competitor Analysis </li>
                  <li><strong>35</strong> Selected Keywords Targeting </li>
                  <li><strong>15</strong> Pages Keyword Targeted</li>

                  <li class="heading"><strong><i>Webpage Optimization</i></strong> </li>
                  <li>Meta Tags Creation</li>
                  <li>Keyword Optimization </li>
                  <li>Image Optimization </li>
                  <li>Inclusion of anchors</li>

                  <li class="heading"><strong><i>Tracking &amp; Analysis</i></strong> </li>
                  <li>Google Analytics Installation</li>
                  <li>Google Webmaster Installation </li>
                  <li>Call To Action Plan </li>
                  <li>Creation of Sitemaps</li>

                  <li class="heading"><strong><i>Reporting</i></strong> </li>
                  <li>Monthly Reporting </li>
                  <li>Recommendation </li>
                  <li>Email Support </li>
                  <li>Phone Support</li>

                  <li class="heading"><strong><i>Off Page Optimization</i></strong></li>
                  <li>Social Bookmarking</li>
                  <li>Slide Share Marketing </li>
                  <li>Forums/FAQ’s </li>
                  <li>Link Building </li>
                  <li>Directory Submission </li>
                  <li>Local Business Listings</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
            <p>$1600 – Quarterly Plan</p>
            <p>$450 – Recurring Monthly Payment</p>
              
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3 >Venture Plan </h3>
                  <p class="">Business Plus</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$1200 <span class="fm">First Month</span></h2>
            </div>
            <div class="packinner">
              <p>For pre-established businesses that aim to maintain their presence and claim the crown.</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=23'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
             <ul class="details">
                  <li class="heading"><strong><i>Prior Analysis</i></strong> </li>
                  <li>Business Analysis</li>
                  <li>Consumer Analysis </li>
                  <li>Competitor Analysis </li>
                  <li>60+ Selected Keywords Targeting </li>
                  <li>30 Pages Keyword Targeted</li>

                  <li class="heading"><strong><i>Webpage Optimization</i></strong> </li>
                  <li>Meta Tags Creation</li>
                  <li>Keyword Optimization </li>
                  <li>Image Optimization </li>
                  <li>Inclusion of anchors Tags </li>
                  <li>Inclusion of anchors Indexing Modifications</li>

                  <li class="heading"><strong><i>Tracking &amp; Analysis</i></strong> </li>
                  <li>Google Places Inclusions</li>
                  <li>Google Analytics Installation</li>
                  <li>Google Webmaster Installation </li>
                  <li>Call To Action Plan </li>
                  <li>Creation of Sitemaps</li>

                  <li class="heading"><strong><i>Reporting</i></strong> </li>
                  <li>Monthly Reporting </li>
                  <li>Recommendation </li>
                  <li>Email Support </li>
                  <li>Phone Support</li>

                  <li class="heading"><strong><i>Off Page Optimization</i></strong> </li>
                  <li>Social Bookmarking</li>
                  <li>Slide Share Marketing </li>
                  <li>Forums/FAQ’s </li>
                  <li>Link Building </li>
                  <li>Directory Submission </li>
                  <li>Local Business Listings</li>
               </ul>
              
            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
              <div class="addnotes ">
                <p>$2600 – Quarterly Plan</p>
                <p>$700 – Recurring Monthly Payment</p>
              
              
            </div>
          </div>
        </div>
      </div>
      
      
      
        </div>
      </div>


                </div>

                <div class="tabs tabs-3dpackages row">
                <div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Basic 3D</h3>
        <p class="">Startup</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$2,995.00  <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=24'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
             <li>30s Duration - HD 1080</li>
              <li>Unlimited Edits/Revisions &amp; Concepts</li>
              <li>Professional Script</li>
              <li>Concept and Storyboards</li>
              <li>3D Modeling</li>
              <li>Texturing</li>
              <li>Rigging</li>
              <li>Animation</li>
              <li>Lighting</li>
              <li>Camera Setting</li>
              <li>Rendering</li>
              <li>Compositing and Special VFX</li>
              <li>Music and Foley</li>
              <li>Custom Setting, 2 Characters &amp; Graphics</li>
              <li>Animation Effects &amp; Visualization</li>
              <li>Voice Over - All accents (M/F)</li>
              <li>Editing and Final Output</li>
          </ul>
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
        <p>10 Business Days <strong>$500</strong> Additional for 
expedited services</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">Popular</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Standard 3D</h3>
        <p class="">Professional</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$4,995.00  <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups 
and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=25'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li>60s Duration - HD 1080</li>
      <li>Unlimited Edits/Revisions &amp; Concepts</li>
      <li>Professional Script</li>
      <li>Concept and Storyboards</li>
      <li>3D Modeling</li>
      <li>Texturing</li>
      <li>Rigging</li>
      <li>Animation</li>
      <li>Lighting</li>
      <li>Camera Setting</li>
      <li>Rendering</li>
      <li>Compositing and Special VFX</li>
      <li>Music and Foley</li>
      <li>Custom Setting, 2 Characters &amp; Graphics</li>
      <li>Animation Effects &amp; Visualization</li>
      <li>Voice Over - All accents (M/F)</li>
      <li>Editing and Final Output</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
       <p>10 Business Days <strong>$500</strong> Additional for 
expedited services</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Premium 3D</h3>
        <p class="">Ultimate</p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$6,995.00  <span class="strike"></span></h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups 
and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=26'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li>120s Duration - HD 1080</li>
      <li>Unlimited Edits/Revisions &amp; Concepts</li>
      <li>Professional Script</li>
      <li>Concept and Storyboards</li>
      <li>3D Modeling</li>
      <li>Texturing</li>
      <li>Rigging</li>
      <li>Animation</li>
      <li>Lighting</li>
      <li>Camera Setting</li>
      <li>Rendering</li>
      <li>Compositing and Special VFX</li>
      <li>Music and Foley</li>
      <li>Custom Setting, 4 Characters &amp; Graphics</li>
      <li>Animation Effects &amp; Visualization</li>
      <li>Voice Over - All accents (M/F)</li>
      <li>Editing and Final Output</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
      <div class="addnotes ">
        <p>10 Business Days <STRONG>$500</STRONG> Additional for 
expedited services</p>
        
        
      </div>
    </div>
  </div>
</div>                </div>
                <div class="tabs tabs-brandingpackages row">
                <div class="container">
  <div class="row packslider">
    <div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Startup Collateral <br>Package</h3>
        <p class=""><span class="strike">$198.00 Only</span></p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$99.00 </h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=27'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li> <strong>2</strong> Stationery Design Set</li>
            <li> <strong>FREE</strong> Fax Template</li>
            <li> Print Ready Formats</li>
            <li> <strong>UNLIMITED</strong> Revisions</li>
            <li> <strong>100%</strong> Satisfaction Guarantee</li>
            <li> <strong>100%</strong> Money Back Guarantee *</li>
          </ul>
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i> +1 862 772 1016</a>
      <div class="addnotes ">
        <p>Add on: $50 for 24 Hours Rush Delivery</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">Popular</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Collateral Classic <br>Package</h3>
        <p class=""><span class="strike">$398.00 Only</span></p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$199.00 </h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=28'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li><strong>2</strong> Stationery Design Set</li>
            <li><strong>UNLIMITED</strong> Revisions</li>
            <li>Flyer Design</li>
            <li>Brochure Design (Bi-fold/Tri-fold)</li>
            <li><strong>100%</strong> Satisfaction Guarantee</li>
            <li><strong>100%</strong> Money Back Guarantee *</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i> +1 862 772 1016</a>
      <div class="addnotes ">
       <p>Add on: $50 for 24 Hours Rush Delivery</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Premium Collateral  <br>Package</h3>
        <p class=""> <span class="strike">$798.00 Only</span></p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$399.00</h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=29'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li><strong>2</strong> Stationery Design Set</li>
            <li>Packaging Design</li>
            <li><strong>UNLIMITED</strong> Revisions</li>
            <li>T-Shirt Design</li>
            <li><strong>100%</strong> Satisfaction Guarantee</li>
            <li><strong>100%</strong> Money Back Guarantee *</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i> +1 862 772 1016</a>
      <div class="addnotes ">
        <p>Add on: $50 for 24 Hours Rush Delivery</p>
        
        
      </div>
    </div>
  </div>
</div>
<div class="col-sm-4">
  <div class="packagebox">
    <p class="populartag">&nbsp;</p>
    <div class="">
      <div class="packhdbox">
        <h3 >Unlimited Collateral  <br>Package</h3>
        <p class=""> <span class="strike">$998.00 Only</span></p>
      </div>
      <div class="pack-wrap">
        <div class="packpricing">
          <h2>$499.00</h2>
        </div>
        <div class="packinner">
          <p>Suitable for potential super-startups and brand revamps for companies.</p>
        </div>
        <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=30'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
        <div class="list-scroll">
          <ul class="details">
            <li><strong>2</strong> Stationery Design Set</li>
            <li>Menu Card Design</li>
            <li>T-Shirt Design</li>
            <li><strong>1</strong> Banner Design</li>
            <li><strong>100%</strong> Satisfaction Guarantee</li>
            <li><strong>100%</strong> Money Back Guarantee *</li>
          </ul>
          
        </div>
      </div>
      
      <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
      <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i> +1 862 772 1016</a>
      <div class="addnotes ">
        <p>Add on: $50 for 24 Hours Rush Delivery</p>
        
        
      </div>
    </div>
  </div>
</div>

  </div>
</div>                </div>
                <div class="tabs tabs-bookwritingpackages row">
                 <div class="container">
  <div class="row packslider">
 <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Cover Design </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$400.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=31'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Enjoy the benefits of working with a world-class firm at an affordable cost. Our talented ghostwriters are at your service with amazing discounts in ghostwriting pricing plans.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Premium Book Video </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$3,900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=32'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Similar to a movie trailer advertising a film, this creative book preview grabs the attention of readers and builds your book’s awareness.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Author Website </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=33'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>The Internet is the fastest-growing marketplace for books, and online book sales are poised to surpass sales through traditional retail outlets.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Professional Audio Book</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$7,000.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=34'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Over the years, the demand for audiobooks has significantly increased because readers are now able to easily download books and listen to them while they are on the move.</li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
       <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Custom Book Illustration </h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$500.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=35'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Our team of experienced in-house artists will work with you to produce a striking custom illustrations that will help your book stand out. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Publishing</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$500.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=36'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>We offer a wide range of services for writers, authors and researchers, such as editing, copyediting, designing, and publishing.  </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Book Marketing</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$2,400.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=37'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Our Digital Marketing Service uses a unique combination of services to introduce your book to potential online readers globally. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="packagebox">
          <p class="populartag">&nbsp;</p>
          <div class="">
            <div class="packhdbox">
                  <h3>Copyrights Certificate</h3>
                  <p class="">Book Writing</p>
            </div>
            <div class="pack-wrap">
            <div class="packpricing">
              <h2>$900.00<span class="fm"></span></h2>
            </div>
            <div class="packinner">
              <p>Payable Amount</p>
            </div>
            <button class="packbtn" onClick="if (!window.__cfRLUnblockHandlers) return false; location.href='order?pack=38'" data-cf-modified-565a0cabfa86dd5c263cfb77-="">Order Now</button>
            <div class="list-scroll">
              <ul class="details">
                  <li>Become a certified published author and gain your well-deserved position among the best authors in the world. </li>

              </ul>

            </div>
            </div>
            
              <a href="javascript:;" class="chatbtn"><i class="fa fa-wechat"></i> Live Chat</a>
              <a href="tel:18627721016" class="numberbtn"><i class="fa fa-phone-square"></i>+1 862 772 1016</a>
                <div class="addnotes">
                  <p>Let's Create</p>
                </div>
          </div>
        </div>
      </div>
    


 </div>
      </div>                </div>


            </div>

        </div>
    </div>
</section>


 <section class="testimonials">
            
                <h3 class="title d-none d-sm-block">What people say</h3> 
                <h3 class="title d-block d-sm-none">Clients</h3>
                <div class="content">
                  <div style="display: none;" class="dots-url" data-url="Logo"></div>
                  <div style="display: none;" class="dots-url" data-url="Web Design"></div>
                  <div style="display: none;" class="dots-url" data-url="Branding"></div>
                  <div style="display: none;" class="dots-url" data-url="Mobile App"></div>
                  <div style="display: none;" class="dots-url" data-url="Content"></div>
                  <div style="display: none;" class="dots-url" data-url="Video"></div>
                  <div style="display: none;" class="dots-url" data-url="SEO"></div>
                  <div class="phrases">

                    
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">
                               Thanks so much for your timeliness and professionalism. My organization logo is awesome! You do good work!
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  BB                
                                    </div>
                                <span class="name"> Barbara </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                               Best experience working with Design Dok. The turnaround for my logo concepts was fast and I was offered multiple logo concepts each time. they asked for feedback on the concepts and zeroed in on what I wanted. I am happy with the final product! It was exactly what I was looking for! I recommend Design Dok for your project.
                                </p>
                            <div class="who">
                                <div class="avatar">BS  </div>
                                <span class="name">Benson </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                               The name says it all Design Dok! I have worked with many graphic designers over the past 3-5 years but working with Design Dok was by far the best experience that I have had in this industry. They did an amazing job getting exactly what we wanted for our logo! Their turnaround time is quick and thorough. I will be back for future work
                                </p>
                            <div class="who">
                                <div class="avatar">
                                    RM                              </div>
                                <span class="name">Ryan Maclachlan </span>
                            </div>
                            </div>
                                </div>
                        </div>
                    
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">I have had many web designs over the years for my fishing business but Ryan and Dan done the job perfect. Their cost beat all the rest and their professionalism was outstanding would definitely recommend.
Many Thanks. 

                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  GM               
                                    </div>
                                <span class="name"> Gary Malloy </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
We have been working with Design Dok on and off for several months now and have always found them helpful and easy to deal with. 
Good value as well as efficient and keeping to deadlines. Thanks Design Dok for all your help!

                                </p>
                            <div class="who">
                                <div class="avatar">JH</div>
                                <span class="name">John Hayes </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                             Fantastic from beginning to end. Can't believe how good my new website looks now! So happy with the end product. If I could give 6 stars I would of. One very happy and satisfied customer. Can't thank you enough Design Dok.
                                </p>
                            <div class="who">
                                <div class="avatar">LV </div>
                                <span class="name">Louis Vanderbeck </span>
                            </div>
                            </div>
                                </div>
                        </div>

                    
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">I wanted to update an identity that appealed to a wide range of people and kept our artisan nature. Design Dok nailed it for me and we're now in the process of developing the identity across a packaging range and support material. At the same time they are helping me get my head around e-commerce. I appreciate the benefits but not how it all works and how to implement it. 100% Recommended. 
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  PJ               
                                    </div>
                                <span class="name"> Phill Joe</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
I have used Design Dok for various projects. I've found them to be a proactive asset to my business with a superb can-do attitude to the short deadlines we work to. The standard of Design Dok’s creative work is excellent. They are more than willing to see projects from concept to completion. They have even been on site for installation projects to manage and oversea the final product.

                                </p>
                            <div class="who">
                                <div class="avatar">FP</div>
                                <span class="name">Flint Pollard </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                            Working with Design Dok has been our best decision all year. As a growing business, we need someone to handle design. We first did one branding project with Design Dok, then another, and another. Soon after we had his agency work on a couple of things, and now have him on our payroll. Best decision ever. They make our brand beautiful. Pure and simple
                                </p>
                            <div class="who">
                                <div class="avatar">EW </div>
                                <span class="name">Eric Waldhorn </span>
                            </div>
                            </div>
                                </div>
                        </div>

                    
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">Design Dok was just an absolute pleasure to work with. I had a lot of doubts about outsourcing my Mobile App Project but I'm so glad I found them. The entire team is friendly, very knowledgeable, diligent and very easy to communicate. I live in the UK but we had no issues with the time difference, they made sure to work around my schedule. They genuinely go the extra mile to provide quality work. I would absolutely recommend them. Thanks guys!
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  PB               
                                    </div>
                                <span class="name"> Peter Bartlett</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
It starts with the best customer centric philosophy - you can't create great software without first understanding the customers business need, budget, and time limitations. Design Dok has filled out their ranks with developers, designers, project managers, client coordinators, and supervisors who are not only true, passionate nerds who love tech but also who really care about delivering business results. I'm proud to say I've worked with Design Dok for 6+ Months, starting just one conceptual mobile project and moving upwards towards creating game-changing Mobile App for clients all across the US. Highly recommended team!

                                </p>
                            <div class="who">
                                <div class="avatar">NG</div>
                                <span class="name">Nick  Geoff </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                           Design Dok has helped me on my latest project, which was unique idea built to our needs. At all times I found them professional, and their understanding of our product was amazing considering what I thought was a difficult and specialized project. Would recommend them.
                                </p>
                            <div class="who">
                                <div class="avatar">SJ </div>
                                <span class="name">Suzanne Jacob</span>
                            </div>
                            </div>
                                </div>
                        </div>

                    
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">Design Dok has been wonderful in content services as like in designs. They did an amazing job by editing my book. They are very creative and very pleased with the quality of the service delivered in a quick timely manner and very accommodating of reviews and changes. Thank you, would sincerely recommend your services to anyone that needs any copy writing
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  CZ               
                                    </div>
                                <span class="name"> Candice Ziller </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
I am a creative writer too but due to lack of time, I had to order my book. I was conscious in the beginning whether this company Design Dok would be able to stand on my expectations or not. But the moment I got my first draft I has truly impressed with their level of work and flawlessness. They have made my idea shine with creativity and a superior writing style.

                                </p>
                            <div class="who">
                                <div class="avatar">GG</div>
                                <span class="name">Gabriel Gomez</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                      Design Dok is a great place to get your book written with a designed cover. They have experienced writers and designers on board who actually walk extra miles to fulfill your expectations. I have worked with them and got truly impressed.
                                </p>
                            <div class="who">
                                <div class="avatar">LW </div>
                                <span class="name">Lambert Wade</span>
                            </div>
                            </div>
                                </div>
                        </div>

                    
                        <div class="">
                             <div class="phrase-inner">
                            <div>
                                <p class="phrase">The Design Dok animation team was very easy to work with and responsive. They went out of his way to ensure I got the video completed in time for an important meeting and did a wonderful job conveying the changes I requested to the art team all along the way!
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  BG               
                                    </div>
                                <span class="name"> Bella Green </span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
I was fortunate enough to find design dok by responding to an email I received. After they successfully completed the first two (2) videos I was so happy with their work. I did 9 more videos for a total of 11. I'm already planning my next 12 projects. These guys are amazing with Mark at the helm. They will have me as a client for as long as they offer the service.

                                </p>
                            <div class="who">
                                <div class="avatar">DA</div>
                                <span class="name">David Agusta</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                      Design Dok did impress me by their professionalism, competency and responsiveness. They listened to my needs and took all my comments immediately into consideration. These days I'm almost used to bad client Service but Design Dok (I dealt with Mark) really made me feel like "Client is King"! I can only recommend Design Dok and I#m grateful for this experience - well done!!
                                </p>
                            <div class="who">
                                <div class="avatar">RD </div>
                                <span class="name">Robert Dobay </span>
                            </div>
                            </div>
                                </div>
                        </div>
                        <div class="">
                            <div class="phrase-inner">
                            <div>
                                <p class="phrase">I hired Design Dok to brand my business then later on also hired them to do SEO for my new business and they did a great job. All people at this office is professional. They know what they do and always fair in pricing and processes. Best of Luck.
                                </p>
                            <div class="who">
                                <div class="avatar">
                                                  KE               
                                    </div>
                                <span class="name"> Kyle Ernest</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                              
I gained some insight into the practices of our industry's foremost link development consultants. I was able to see for myself that the SEO guys at Design Dok are for real and they've done a good job of consolidating theory with evidence and thereupon manifesting best practices for link development.

                                </p>
                            <div class="who">
                                <div class="avatar">VM</div>
                                <span class="name">Valentine M</span>
                            </div>
                            </div>
                            <div>
                                <p class="phrase">
                     Working with Design Dok SEO Services team was a pleasure. They listened to our ideas and worked hard to incorporate our ideas into the web site design for us. Their Google Search Optimization / Marketing services are already working and we look forward to continuing our relationship with Design Dok Design and SEO Services.
                                </p>
                            <div class="who">
                                <div class="avatar">KWpa </div>
                                <span class="name">Kyle Willburn </span>
                            </div>
                            </div>
                                </div>
                        </div>

                                        </div>  
                </div>
            </section>


</div>

<section class="contacts">
    <div class="container">
        <div class="contacts-wrap">
            <div class="row">
                <div class="col-lg-6">
                    <div class="contact-form">
                        <div class="content">
                            <h2 class="form-name">Let’s talk business</h2>
                        </div>
                        <!-- <h3 class="title">Services</h3> -->

<div role="form">
    <form method="POST" action="webpages/bottomFormController.php"  enctype="multipart/form-data">

        <!-- <ul class="tags">
            <li class="item">
                <span class="wpcf7-form-control-wrap appdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="App Design" /><span class="wpcf7-list-item-label">App Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Web Design" /><span class="wpcf7-list-item-label">Web Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap copywriting"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Graphic Design" /><span class="wpcf7-list-item-label">Graphic Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdev"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Web Dev" /><span class="wpcf7-list-item-label">Web Dev</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap motion"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Animation" /><span class="wpcf7-list-item-label">Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap branding"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Logo and Branding" /><span class="wpcf7-list-item-label">Logo and Branding</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap ios"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="App Dev" /><span class="wpcf7-list-item-label">App Dev</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap other"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Promo Video" /><span class="wpcf7-list-item-label">Promo Video</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap other"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Seo" /><span class="wpcf7-list-item-label">SEO</span></label></span></span></span>
            </li>
        </ul> -->
        <div class="app-input-group">
            <span><input type="text" name="username" value="" size="40" class="input" required /></span>
            <label>Name</label>
        </div>
        <div class="app-input-group">
            <span><input type="text" name="useremail" value="" size="40" class="input" required /></span>
            <label>Email</label>
        </div>
      
             <div class="app-input-group order-phone">
            <span><input type="text" name="userphone" value="" size="40" class="input" id="phone-coun" placeholder="Phone" required /></span>
     
        </div>
            <!--<label>Phone</label>-->
       
        <div class="app-input-group">
            <span>
            <textarea name="userdetail" cols="40" rows="1" class="textarea autoheight" required ></textarea>
            </span>
            <label>Project details</label>
        </div>
   
        <div class="send-wrap">
            <!-- <div class="attach">
                <span class="attach-desc">Attach file</span><br />
                <span class="wpcf7-form-control-wrap file-625"><input type="file" name="wordfile" size="40" class="wpcf7-form-control wpcf7-file input file" accept=".jpg,.jpeg,.png,.pdf" aria-invalid="false" /></span>
            </div> -->
                <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit submit" /></p>
                 <script type="565a0cabfa86dd5c263cfb77-text/javascript">
                document.getElementById('blocation').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
                    <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
              <input type="hidden" id="blocation" name="blocationURL" value="http://www.designdok.com/packages.php" />
            </div>
            </form>
        </div>                           
                    </div>  
                </div>
                <div class="col-lg-6">
                    <div class="social-info-wrap">

                        <div class="social-info">
                            <div class="content">
                                <h2 class="form-name">Contacts</h2>
                            </div>

                            <div class="social-flex-wrap">

                                <div class="hire-wrap">
                                    <!-- <h3 class="title">Hire</h3> -->
                                    <a href="/cdn-cgi/l/email-protection#402f322425320024253329272e242f2b6e232f2d" class="mail"><span class="__cf_email__" data-cfemail="cda2bfa9a8bf8da9a8bea4aaa3a9a2a6e3aea2a0">[email&#160;protected]</span></a><a
                                    class="phone" href="tel:+18627721016">+1 862 772 1016</a>
                                </div>
                                <div class="follow-wrap">
                                    <h3 class="title">Follow</h3>
                                    <ul>
                                     <li><a href="https://www.facebook.com/designdok/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                     <li><a href="https://www.linkedin.com/company/design-dok"><i class="fa fa-linkedin"></i></a></li>
                                     <li><a href="https://dribbble.com/designdok" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                                     <li><a href="https://www.instagram.com/designdok/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                   </ul>
                                </div>
                                <div class="map">
                                  <img src="assets/images/animation_banner.gif">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>  
            </div>     
        </div>
    </div>    
</section> 



  <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h3>Services <i class="fa fa-plus"></i> </h3>
                <ul>
                    <li><a href="https://www.designdok.com/logo-design">Logo Design</a></li>
            <li><a href="https://www.designdok.com/branding">Branding</a></li>
            <li><a href="https://www.designdok.com/website-design-development">Website Design & Development</a></li>
            <li><a href="https://www.designdok.com/motion-graphics">Motion Graphics</a></li>
            <li><img data-src="assets/images/cards.png" class="brandsvg lazy"></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/seo">SEO</a></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/content">Book Writing</a></li>
                </ul>
            </div>
            <div class="col-md-3">

                <ul>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/seo">SEO</a></li>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/content">Book Writing</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>Quick links <i class="fa fa-plus"></i></h3>
                <ul>
                    <li><a href="https://www.designdok.com/company">Company</a></li>
                    <li><a href="https://www.designdok.com/works">Portfolio</a></li>
                    <li><a href="https://www.designdok.com/how-it-works">How It Works</a></li>
                    <li><a href="https://www.designdok.com/contact">Hire us</a></li>
                    <li><a href="https://www.designdok.com/terms">Terms & Condition</a></li>
                    <li><a href="https://www.designdok.com/privacy-policy">Privacy Policy</a></li>
                </ul>
            </div>



            <div class="col-md-3">
                <h3>About <i class="fa fa-plus"></i></h3>
                <ul>
                    <!--<li><a href="#">Frequently Asked Questions</a></li>-->
                    <li><a href="tel:+18627721016" class="bluecolr">+1 862 772 1016</a></li>
                    <li>One gateway center, Newark, New Jersey, USA <br>   <a href="https://goo.gl/maps/zprHU819QK5tRo176" style="font-weight: bold;">Go to location</a></li><br>
                    <li>39899 Balentine Drive, Newark, California, 94560, USA<br> <a href="https://goo.gl/maps/NP1C31dUhhYu3sMA8" style="font-weight: bold;">Go to location</a></li>
                    
                </ul>
            </div>

            
        </div>
        <div class="row justify-content-center">
          <div class="col-md-12">
             <span>&copy; 2019 Design Dok</span>
             <p>&nbsp; &nbsp; DESIGN DOK A COMPANY OF OCTA GROUP DBA (TIN): 98-1261553</p>
          </div>
        </div>
    </div>
</footer>







         
   

    </div>
    </div>






    





<div class="floatbutton">
    <div class="btns_wrap">
            
            <a href="javascript:;" class="chat_wrap" onclick="if (!window.__cfRLUnblockHandlers) return false; setButtonURL();" data-cf-modified-565a0cabfa86dd5c263cfb77-="">
              <span class="icoo"><i class="fa fa-comment"></i></span>
              <span>Chat With Us</span>
            </a>
            <a href="tel:+18627721016" class="call_wrap">
             <span class="icoo"><i class="fa fa-phone"></i></span>
              <span> +1 862 772 1016 </span>
            </a>
          </div>


      <div class="clickbutton"><div class="crossplus"><i class="fa fa-send"></i></div></div>
      <div class="banner-form">
        <h3>Chat With Us to <br><Strong>Avail 50% Discount</Strong></h3>
        <div class="banform">
          <div class="container">
            <div class="row">
                <div class="ban-form">
                  <form class="cmxform" id="bannerform"  method="POST" action="webpages/floatingFormController.php">
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="username" name="fName" minlength="2" type="text" placeholder="Enter your name" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="cemail" type="email" name="fEmail" placeholder="Enter email here" required>
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="phone-coun" name="fNumber" type="number" placeholder="Phone Number"  required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <textarea name="fMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
                        </div>
                      </div>
                      
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input name="submit" type="submit" placeholder="Connect With Us" required />
        
                          <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="565a0cabfa86dd5c263cfb77-text/javascript">
                        document.getElementById('flocation').value = window.location.href;
                      </script>
                      <input type="hidden" name="hiddencapcha" value="">
                            <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
                      <input type="hidden" id="flocation" name="flocationURL" value="" />
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>
        </div>  
    </div>
    </div>






<div class="ys-layer"></div>
<div class="ys-container" id="ys-container">
   <div class="ys-box">
       <a class="ys-popup-close ys-exit" href="#">x</a>
       <div class="ys-popup-content">
           <!-- <p>Are Your Sure?</p>
           <a href="#" class="ys-exit">Exit</a> -->

           <div class="popupform tabform clearfix  text-left">
           <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>
           <span class="heading">Confused? </span>
             <h2 class="text-center">Our smart and friendly client support team is available to guide you through the creative process and answer all of your questions.</h2>
             <form id="popupfrm" class="cmxform"  method="POST" action="webpages/exitFormController.php">

               <div class="fldst btnattach">
                 <!-- <input class="submit" type="submit" value="" class="btnsb" /> -->
                 <a class="callus" href="tel:+18627721016"> Free design consultation <i class="fa fa-phone"></i> +1 862 772 1016</a>
               </div>

               <div class="fldst">
                <p>Send us your number to speak with an actual human.</p>
                 <input id="phone-coun" name="fNumber" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
                 <button class="newbtn" type="submit">Submit</button>
                 <script type="565a0cabfa86dd5c263cfb77-text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
              
              <input type="hidden" id="location" name="flocationURL" value="http://www.designdok.com/packages.php" />
               </div>

               
              
               <p class="lst-p">Not ready for a call? <a href="javascript:;" onClick="if (!window.__cfRLUnblockHandlers) return false; $zopim.livechat.window.toggle();" data-cf-modified-565a0cabfa86dd5c263cfb77-=""> Discuss with our strategist</a></span></p>

             </form>
           </div>
       </div>
   </div>
</div>

<!--<div class="stiky_foter">-->
<!--  <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>-->
<!--  <p>Let’s conceptualize and design your idea -->
<!--with a creative professionals. </p>-->
<!--  <a href="javascript:;" class="chatbtn linddbtn">Chat to get 50% Discount</a>-->
<!--</div>-->

<script type="565a0cabfa86dd5c263cfb77-text/javascript" src='assets/js/mlib.js'></script>
<!--<script type="text/javascript" src="assets/js/jPages.js"></script>-->
<script type="565a0cabfa86dd5c263cfb77-text/javascript"> $(function(){$("div.holder").jPages({containerID : "review-style", first       : false, previous    : false, perPage:    15, next        : false, pause       : false, last        : false, midRange:   5, links       : "blank"}); }); </script>

<script type="565a0cabfa86dd5c263cfb77-text/javascript" src='assets/js/functions.js'></script>
<!--<script type='text/javascript' src='assets/js/gsapAnimation.js'></script>-->


<!-- Start of  Zendesk Widget script -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=570b7f92-0bba-46d4-934c-3d9ba381480f" type="565a0cabfa86dd5c263cfb77-text/javascript"> </script>
<!-- End of  Zendesk Widget script -->








<script type="565a0cabfa86dd5c263cfb77-text/javascript">
  function setButtonURL(){
//CUGICHelper.bubbleChat.toggle();
$zopim.livechat.window.toggle();
//LC_API.open_chat_window();
// Tawk_API.toggle();
//tidioChatApi.open();
}
</script>

<script type="565a0cabfa86dd5c263cfb77-text/javascript">
   window._mfq = window._mfq || []; (function() {var mf = document.createElement("script"); mf.type = "text/javascript"; mf.async = true; mf.src = "//cdn.mouseflow.com/projects/a907cee1-6091-49df-a0ff-d8f16b43e6af.js"; document.getElementsByTagName("head")[0].appendChild(mf); })();
</script>

<script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@12.0.0/dist/lazyload.min.js" type="565a0cabfa86dd5c263cfb77-text/javascript"></script>
<script type="565a0cabfa86dd5c263cfb77-text/javascript">
 $(function() {
        var myLazyLoad = new LazyLoad({
   elements_selector: ".lazy"
   // load_delay: 300 //adjust according to use case
});
    });
</script>

<!--  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
<script>
var options = {
debug: false,
}







if ($.cookie('ysExit') == 1)
    {

    }
else{
ysExit(options);
}

</script>



Global site tag (gtag.js) - Google Analytics
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script> -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1" type="565a0cabfa86dd5c263cfb77-text/javascript"></script>
<script type="565a0cabfa86dd5c263cfb77-text/javascript">
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script>    

<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="565a0cabfa86dd5c263cfb77-|49" defer=""></script></body>
</html>
