

<html lang="en-US"
  itemscope 
  itemtype="http://schema.org/WebSite" 
  prefix="og: http://ogp.me/ns#" >
<head>
    
<title>Get the perfect logo design - or any design in over 90 categories!</title>
<meta name="description"  content="Design Dok is a digital design agency specializing in branding, animation, mobile and web design and development." />

     

<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">




<link href="favicon.ico" rel="icon" />

      
<link rel='dns-prefetch' href='//s.w.org' />

<!--<link rel='stylesheet' id='main-style-css'  href='assets/css/mstyle.css' type='text/css' media='all' />-->
<link rel='stylesheet' id='main-style-css'  href='assets/css/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-style-css'  href='assets/css/m-style.css' type='text/css' media='all' />
<link rel='stylesheet' id='main-style-css'  href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css' type="text/css" />

<!--[if IE]>
  <script src="assets/js/html5.js"></script>
<![endif]-->

 

</head>


<body class="home blog contactpage">

    <div class="app-content">
        <div class="main">
            
             

<noscript>
<div id="jqcheck"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB60lEQVQ4T2NkwAHePzrxf3ebL1jWp/0oA5egGiM2pVgFQQq31uj/N/ANZvj+8T3D7aNHGDwbTxNvwKtbO/9f3dLHYJ+axfDn5w+GI/NnMRhFtTEISJtjGIIh8Pv39/87ak0ZzCLiGMRUNMCufnLxDMOlrZsY3JtOMrCwsKPowTDg3tGZ/59f2sVgFRvPkO+bAzZgwsZJDEcXzWNQtIlikDGIwG3Az+9v/+9qsGOwTc1h4JeQhhswcfMUhrcP7zEcXzyXwb3xMAMbuwDcEBTTzi7P/s/M8IFB3zccbDPMBSADQODs2sUMzFwyDIah/ZgGfHt/7/+BvmAGm+RsBl4RMawGfHr5jOHowlkMjiUbGDj55MCGwE060Of1X0RZi0Hb2Q4e3eguAElc2X2A4e2DmwwOhVsRBnx6cfH/yXm5DFZxyQxcAoJ4Dfj24T3DsUVzGcwSJjLwSxkygk3ZVmv4X805gkHZRBNXwkQRv3/+NsP1nUsYvFvOMzI+PLXo/73DSxgsouIYOHj5UBRi8wJIwY8vnxlOLV/CIGcewsC4vkDhv01yLoOIoiqG7bgMACn88Owxw8HpvQyMGwqV/vs19TMwQnxDEthYW8DAeGCC3/9XN46TpBGmWEzDkoHx06dP/z9//kyWAby8vAwAcza2SBMOSCMAAAAASUVORK5CYII=" alt="No Script" /> Javascript is disabled. Please enable it for better working experience.</div>
</noscript>
<header class="header-home fill"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<a href="https://www.designdok.com/">
    <div class="logo">
       <img src="assets/images/logo.svg" alt=""> 
      <!--<img src="assets/images/design-dok-christmas.png" alt=""> -->
    </div>
</a>

  <div class="menu-wrap">
      <a class="mobile-hireus num" href="tel:+18627721016">+1 862 772 1016</a>

    <a class="mobile-hireus gotoform" href="Javascript:;">Hire us</a>

    <button class="hamburger hamburger--spring js-hamburger" type="button"
  aria-label="Menu" aria-controls="navigation" aria-expanded="true/false">
      <span class="hamburger-box">
      <span class="hamburger-inner"></span>
      </span>
    </button>

    <div class="menu">
      <ul id="menu" class="">
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4971 homeclass hidemenu"><a href="https://www.designdok.com/">Home</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4970 dropdown hidemenu">
          <a href="https://www.designdok.com/services">Services</a>
          <ul class="ddlist">
            <li><a href="https://www.designdok.com/logo-design" class="active">Logo Design</a></li>
            <li><a href="https://www.designdok.com/branding">Branding</a></li>
            <li><a href="https://www.designdok.com/website-design-development">Website Design & Development</a></li>
            <li><a href="https://www.designdok.com/motion-graphics">Motion Graphics</a></li>
            <li><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li><a href="https://www.designdok.com/seo">SEO</a></li>
            <li><a href="https://www.designdok.com/content">Book Writing</a></li>
          </ul>
        </li>
        
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="https://www.designdok.com/works">Portfolio</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="packages">Packages</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="combo-packages">Combo Packages</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5247 hidemenu"><a href="https://www.designdok.com/reviews">Reviews</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5247 hidemenu"><a href="https://www.designdok.com/how-it-works">How It Works</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973 hidemenu"><a href="https://www.designdok.com/company">Company</a></li>
        <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4973"><a class="headnumber" href="tel:+18627721016"><i class="fa fa-phone"></i>+1 862 772 1016</a></li>
        <li class="hire-us menu-item menu-item-type-post_type menu-item-object-page menu-item-4974 hidemenu"><a href="https://www.designdok.com/contact">Get a Quote</a></li>
        <li class="hire-us menu-item menu-item-type-post_type menu-item-object-page menu-item-4974 gotoform"><a href="Javascript:;">Hire us</a></li>
        
      </ul>
      <div class="close-i"></div>
    </div>    
  </div>


<div class="topformcontainer">
    <div class="topformwrap">
      <div class="formheading">
        <h2>Let's Get Started Exclusive Offer </h2>
      </div>
      <div class="formbody">
        <div class="container">
  <div class=" col-lg-12 col-xl-12 text-center">
    <div class="home-banner-content"  >
      <div class="analyzeform col-lg-10 offset-lg-1">
        <form class="" id="banform" method="POST" action="webpages/bannerFormController.php">
          <div class="row">
            <div class="wrap">
              <div class="dtf">
                <input id="fname" name="bName" autocomplete="off" minlength="5" class="round" type="text" placeholder="Enter Name" required="">
              </div>
              <div class="dtf">
                <input id="cemail" type="email" autocomplete="off" name="bEmail" placeholder="Enter email here" required="">
              </div>
              <div class="dtf">
                <input id="phone-coun" name="bNumber" autocomplete="off" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
              </div>
              <div class="dtf">
                <textarea name="bMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
              </div>
              <div class="dtf text-left">
                <input class="submit" type="submit" value="Contact Team">
                <script type="15e061cefbeb19d2a20f820b-text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
                    <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
              <input type="hidden" id="location" name="blocationURL" value="" />
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>      </div>
    </div>
    <div class="topformswitch">
      <div class="switchicon">
        <span class="fa fa-chevron-down"></span>
      </div>
      <h4>Avail <span>50%</span> DISCOUNT</h4>
    </div>
  </div>
  
    <!--<div class="eggoffer">-->
    <!--    <a href="javascript:;" onclick="setButtonURL()">-->
    <!--      <div class="top">-->
    <!--        <figure>-->
              <!--<img src="assets/images/blackfriiday.png">-->
    <!--        <img src="assets/images/christmas.png">-->
    <!--        </figure>-->
    <!--      </div>-->
    <!--    </a>-->
    <!--</div> -->

</header>






<section class="contacts" style="margin-top: 80px;">
    <div class="container">
        <div class="contacts-wrap">
            <div class="row">
                <div class="col-lg-6">
                    <div class="contact-form">
                        <div class="content">
                            <h2 class="form-name">Let’s design together</h2>
                        </div>
                        

                       <div role="form">
    <form method="POST" action="webpages/bottomFormController.php"  enctype="multipart/form-data">

        <!-- <ul class="tags">
            <li class="item">
                <span class="wpcf7-form-control-wrap appdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="App Design" /><span class="wpcf7-list-item-label">App Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdesign"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Web Design" /><span class="wpcf7-list-item-label">Web Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap copywriting"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Graphic Design" /><span class="wpcf7-list-item-label">Graphic Design</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap webdev"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Web Dev" /><span class="wpcf7-list-item-label">Web Dev</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap motion"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Animation" /><span class="wpcf7-list-item-label">Animation</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap branding"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Logo and Branding" /><span class="wpcf7-list-item-label">Logo and Branding</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap ios"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="App Dev" /><span class="wpcf7-list-item-label">App Dev</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap other"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Promo Video" /><span class="wpcf7-list-item-label">Promo Video</span></label></span></span></span>
            </li>
            <li class="item">
                <span class="wpcf7-form-control-wrap other"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><label><input type="checkbox" name="services[]" value="Seo" /><span class="wpcf7-list-item-label">SEO</span></label></span></span></span>
            </li>
        </ul> -->
        <div class="app-input-group">
            <span><input type="text" name="username" value="" size="40" class="input" required /></span>
            <label>Name</label>
        </div>
        <div class="app-input-group">
            <span><input type="text" name="useremail" value="" size="40" class="input" required /></span>
            <label>Email</label>
        </div>
      
             <div class="app-input-group order-phone">
            <span><input type="text" name="userphone" value="" size="40" class="input" id="phone-coun" placeholder="Phone" required /></span>
     
        </div>
            <!--<label>Phone</label>-->
       
        <div class="app-input-group">
            <span>
            <textarea name="userdetail" cols="40" rows="1" class="textarea autoheight" required ></textarea>
            </span>
            <label>Project details</label>
        </div>
   
        <div class="send-wrap">
            <!-- <div class="attach">
                <span class="attach-desc">Attach file</span><br />
                <span class="wpcf7-form-control-wrap file-625"><input type="file" name="wordfile" size="40" class="wpcf7-form-control wpcf7-file input file" accept=".jpg,.jpeg,.png,.pdf" aria-invalid="false" /></span>
            </div> -->
                <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit submit" /></p>
                 <script type="15e061cefbeb19d2a20f820b-text/javascript">
                document.getElementById('blocation').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
                    <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
              <input type="hidden" id="blocation" name="blocationURL" value="http://www.designdok.com/contact.php" />
            </div>
            </form>
        </div>                         
                    </div>  
                </div>
                <div class="col-lg-6">
                    <div class="social-info-wrap">

                        <div class="social-info">
                            <div class="content">
                                <h2 class="form-name">Contacts</h2>
                            </div>

                            <div class="social-flex-wrap">

                                <div class="hire-wrap">
                                    
                                    <a href="/cdn-cgi/l/email-protection#204f524445526044455349474e444f4b0e434f4d" class="mail"><span class="__cf_email__" data-cfemail="7b14091f1e093b1f1e08121c151f141055181416">[email&#160;protected]</span></a><a
                                    class="phone" href="tel:+18627721016">+1 862 772 1016</a>
                                </div>
                                <div class="follow-wrap">
                                    <h3 class="title">Follow</h3>
                                    <ul>
                                     <li><a href="https://www.facebook.com/designdok/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                     <li><a href="https://www.linkedin.com/company/design-dok"><i class="fa fa-linkedin"></i></a></li>
                                     <li><a href="https://dribbble.com/designdok" target="_blank"><i class="fa fa-dribbble"></i></a></li>
                                     <li><a href="https://www.instagram.com/designdok/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                   </ul>
                                </div>
                                <div class="map">
                                  <img src="assets/images/animation_banner.gif">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>  
            </div>     
        </div>
    </div>    
</section> 


  <footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h3>Services <i class="fa fa-plus"></i> </h3>
                <ul>
                    <li><a href="https://www.designdok.com/logo-design">Logo Design</a></li>
            <li><a href="https://www.designdok.com/branding">Branding</a></li>
            <li><a href="https://www.designdok.com/website-design-development">Website Design & Development</a></li>
            <li><a href="https://www.designdok.com/motion-graphics">Motion Graphics</a></li>
            <li><img data-src="assets/images/cards.png" class="brandsvg lazy"></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/seo">SEO</a></li>
            <li class="cust_visible_xs"><a href="https://www.designdok.com/content">Book Writing</a></li>
                </ul>
            </div>
            <div class="col-md-3">

                <ul>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/mobile-apps">Mobile Apps</a></li>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/seo">SEO</a></li>
            <li class="cust_hide_xs"><a href="https://www.designdok.com/content">Book Writing</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>Quick links <i class="fa fa-plus"></i></h3>
                <ul>
                    <li><a href="https://www.designdok.com/company">Company</a></li>
                    <li><a href="https://www.designdok.com/works">Portfolio</a></li>
                    <li><a href="https://www.designdok.com/how-it-works">How It Works</a></li>
                    <li><a href="https://www.designdok.com/contact">Hire us</a></li>
                    <li><a href="https://www.designdok.com/terms">Terms & Condition</a></li>
                    <li><a href="https://www.designdok.com/privacy-policy">Privacy Policy</a></li>
                </ul>
            </div>



            <div class="col-md-3">
                <h3>About <i class="fa fa-plus"></i></h3>
                <ul>
                    <!--<li><a href="#">Frequently Asked Questions</a></li>-->
                    <li><a href="tel:+18627721016" class="bluecolr">+1 862 772 1016</a></li>
                    <li>One gateway center, Newark, New Jersey, USA <br>   <a href="https://goo.gl/maps/zprHU819QK5tRo176" style="font-weight: bold;">Go to location</a></li><br>
                    <li>39899 Balentine Drive, Newark, California, 94560, USA<br> <a href="https://goo.gl/maps/NP1C31dUhhYu3sMA8" style="font-weight: bold;">Go to location</a></li>
                    
                </ul>
            </div>

            
        </div>
        <div class="row justify-content-center">
          <div class="col-md-12">
             <span>&copy; 2019 Design Dok</span>
             <p>&nbsp; &nbsp; DESIGN DOK A COMPANY OF OCTA GROUP DBA (TIN): 98-1261553</p>
          </div>
        </div>
    </div>
</footer>






         
   

    </div>
    </div>






    





<div class="floatbutton">
    <div class="btns_wrap">
            
            <a href="javascript:;" class="chat_wrap" onclick="if (!window.__cfRLUnblockHandlers) return false; setButtonURL();" data-cf-modified-15e061cefbeb19d2a20f820b-="">
              <span class="icoo"><i class="fa fa-comment"></i></span>
              <span>Chat With Us</span>
            </a>
            <a href="tel:+18627721016" class="call_wrap">
             <span class="icoo"><i class="fa fa-phone"></i></span>
              <span> +1 862 772 1016 </span>
            </a>
          </div>


      <div class="clickbutton"><div class="crossplus"><i class="fa fa-send"></i></div></div>
      <div class="banner-form">
        <h3>Chat With Us to <br><Strong>Avail 50% Discount</Strong></h3>
        <div class="banform">
          <div class="container">
            <div class="row">
                <div class="ban-form">
                  <form class="cmxform" id="bannerform"  method="POST" action="webpages/floatingFormController.php">
                    <div class="row">
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="username" name="fName" minlength="2" type="text" placeholder="Enter your name" required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="cemail" type="email" name="fEmail" placeholder="Enter email here" required>
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input id="phone-coun" name="fNumber" type="number" placeholder="Phone Number"  required />
                        </div>
                      </div>
                      <div class="col-lg-12">
                        <div class="fldset">
                          <textarea name="fMessage" id="" rows="7" placeholder="Talk About Your Project"></textarea>
                        </div>
                      </div>
                      
                      <div class="col-lg-12">
                        <div class="fldset">
                          <input name="submit" type="submit" placeholder="Connect With Us" required />
        
                          <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="15e061cefbeb19d2a20f820b-text/javascript">
                        document.getElementById('flocation').value = window.location.href;
                      </script>
                      <input type="hidden" name="hiddencapcha" value="">
                            <input type="hidden" name="pc" value="">
                <input type="hidden" name="cip" value="">
                <input type="hidden" name="ctry" value="">
                      <input type="hidden" id="flocation" name="flocationURL" value="" />
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
            </div>
          </div>
        </div>  
    </div>
    </div>






<div class="ys-layer"></div>
<div class="ys-container" id="ys-container">
   <div class="ys-box">
       <a class="ys-popup-close ys-exit" href="#">x</a>
       <div class="ys-popup-content">
           <!-- <p>Are Your Sure?</p>
           <a href="#" class="ys-exit">Exit</a> -->

           <div class="popupform tabform clearfix  text-left">
           <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>
           <span class="heading">Confused? </span>
             <h2 class="text-center">Our smart and friendly client support team is available to guide you through the creative process and answer all of your questions.</h2>
             <form id="popupfrm" class="cmxform"  method="POST" action="webpages/exitFormController.php">

               <div class="fldst btnattach">
                 <!-- <input class="submit" type="submit" value="" class="btnsb" /> -->
                 <a class="callus" href="tel:+18627721016"> Free design consultation <i class="fa fa-phone"></i> +1 862 772 1016</a>
               </div>

               <div class="fldst">
                <p>Send us your number to speak with an actual human.</p>
                 <input id="phone-coun" name="fNumber" required="" type="number" rangelength="[2,15]" placeholder="Enter phone here">
                 <button class="newbtn" type="submit">Submit</button>
                 <script type="15e061cefbeb19d2a20f820b-text/javascript">
                document.getElementById('location').value = window.location.href;
              </script>
              <input type="hidden" name="hiddencapcha" value="">
              
              <input type="hidden" id="location" name="flocationURL" value="http://www.designdok.com/contact.php" />
               </div>

               
              
               <p class="lst-p">Not ready for a call? <a href="javascript:;" onClick="if (!window.__cfRLUnblockHandlers) return false; $zopim.livechat.window.toggle();" data-cf-modified-15e061cefbeb19d2a20f820b-=""> Discuss with our strategist</a></span></p>

             </form>
           </div>
       </div>
   </div>
</div>

<!--<div class="stiky_foter">-->
<!--  <figure style="background-image: url(assets/images/linda-dok.jpg);"> </figure>-->
<!--  <p>Let’s conceptualize and design your idea -->
<!--with a creative professionals. </p>-->
<!--  <a href="javascript:;" class="chatbtn linddbtn">Chat to get 50% Discount</a>-->
<!--</div>-->

<script type="15e061cefbeb19d2a20f820b-text/javascript" src='assets/js/mlib.js'></script>
<!--<script type="text/javascript" src="assets/js/jPages.js"></script>-->
<script type="15e061cefbeb19d2a20f820b-text/javascript"> $(function(){$("div.holder").jPages({containerID : "review-style", first       : false, previous    : false, perPage:    15, next        : false, pause       : false, last        : false, midRange:   5, links       : "blank"}); }); </script>

<script type="15e061cefbeb19d2a20f820b-text/javascript" src='assets/js/functions.js'></script>
<!--<script type='text/javascript' src='assets/js/gsapAnimation.js'></script>-->


<!-- Start of  Zendesk Widget script -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=570b7f92-0bba-46d4-934c-3d9ba381480f" type="15e061cefbeb19d2a20f820b-text/javascript"> </script>
<!-- End of  Zendesk Widget script -->








<script type="15e061cefbeb19d2a20f820b-text/javascript">
  function setButtonURL(){
//CUGICHelper.bubbleChat.toggle();
$zopim.livechat.window.toggle();
//LC_API.open_chat_window();
// Tawk_API.toggle();
//tidioChatApi.open();
}
</script>

<script type="15e061cefbeb19d2a20f820b-text/javascript">
   window._mfq = window._mfq || []; (function() {var mf = document.createElement("script"); mf.type = "text/javascript"; mf.async = true; mf.src = "//cdn.mouseflow.com/projects/a907cee1-6091-49df-a0ff-d8f16b43e6af.js"; document.getElementsByTagName("head")[0].appendChild(mf); })();
</script>

<script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@12.0.0/dist/lazyload.min.js" type="15e061cefbeb19d2a20f820b-text/javascript"></script>
<script type="15e061cefbeb19d2a20f820b-text/javascript">
 $(function() {
        var myLazyLoad = new LazyLoad({
   elements_selector: ".lazy"
   // load_delay: 300 //adjust according to use case
});
    });
</script>

<!--  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js"></script>
<script>
var options = {
debug: false,
}







if ($.cookie('ysExit') == 1)
    {

    }
else{
ysExit(options);
}

</script>



Global site tag (gtag.js) - Google Analytics
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script> -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139554973-1" type="15e061cefbeb19d2a20f820b-text/javascript"></script>
<script type="15e061cefbeb19d2a20f820b-text/javascript">
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-139554973-1');





</script>    

<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="15e061cefbeb19d2a20f820b-|49" defer=""></script></body>
</html>
